import java.awt.*;
import java.util.*;
import java.applet.*;
import java.net.*; //La clase URL est�n en el paquete NET

public class Tablero extends Applet{
	Image fondo;
	Graphics noseve;
	public static final int SIZE = 5;
	Image imagenes[][];
	Hueco huecos[][];
	AudioClip error, acierto, exito;
	Point blanco;
	Button boton;
	
   	public void init(){
   		fondo = createImage(240, 300);
   		noseve = fondo.getGraphics();
   		
   		//Las filas valen 5 veces m�s que las columnas
   		imagenes = new Image[SIZE][SIZE]; //declaramos el vector no las imagenes, 25 punteros que apuntan a objetos de la clase imagen con el valor null
   		for(int i = 0; i < SIZE; i++){
   			for(int j = 0; j < SIZE; j++){
   				if(!((i == SIZE-1) && (j == SIZE-1))){ // Excepci�n cuando tanto i como j valen 4 (4*5 = 20) + 4 + 1 = 25 (pero el 25 no existe en imagenes, solo hay 24)
   				// Mientras esto no se produzca realizar lo de abajo
   					imagenes[i][j] = getImage(getCodeBase(), "botones/"+ ((i*SIZE)+ j + 1) + ".gif");//declaramos las imagenes dentro del vector
   				}
   			}
   		}
   		//Declaramos los huecos y les asignamos imagenes
   		huecos = new Hueco[SIZE][SIZE];
   		for(int i = 0; i < SIZE; i++){
   			for(int j = 0; j < SIZE; j++){
   				huecos[i][j] = new Hueco(imagenes[j][i], (i*SIZE)+j+1 );//Tenemos que pasar una imagen y un entero con el valor
   			}
   		}
   		//Declaramos los sonidos
   		try{
	   		error = getAudioClip(new URL(getDocumentBase(), "sonidos/error.wav")); //En este caso utiliza nuestro ordenador como direcci�n
	   		acierto = getAudioClip(new URL(getDocumentBase(), "sonidos/correct.wav"));
	   		exito = getAudioClip(new URL(getDocumentBase(), "sonudos/exito.wav"));
   		}catch(MalformedURLException e){} //Hay que someter las l�neas a tratamiento de excepciones, que es por si no encuentra la URL a la que se intenta acceder. Es una obligatoriedad del m�todo constructor de la clase URL
   		
   		//new URL() = Una URL es una direcci�n de un servidor de internet
   		//Apache = Es un servidor de aplicaciones web
   		//IP = internet protocol, IP adrees = direcci�n que sigue el protocolo de internet
   		
   		blanco = new Point(SIZE-1, SIZE-1);
   		
   		//Para desordenar las imagenes
   		boton = new Button("Empezar");
   		this.setLayout(new BorderLayout());
   		this.add("South", boton);
   				
   	}
   
  	public void start(){
   	
   	}
   
    public void paint(Graphics fondoVisible){
   		noseve.setColor(Color.white);
    	noseve.fillRect(0, 0, 500, 550);
   		
   		for(int i = 0; i < SIZE; i++){
   			for(int j = 0; j < SIZE; j++){
   				//noseve.drawImage(imagenes[i][j], i*48, j*48, this) --> posX, posY, ancho y alto // Si en la ecuaci�n ponemos ((i*SIZE) + j + 1) tendr�amos que poner imagenes[j][i] aqu�
   				 huecos[i][j].dibujar(noseve, this, i, j); //Le pasamos un objeto de la clase graphics, el applet, y las posiciones d�nde se tienen que colocar
   				 
   			}  					
   		}
   		
   		
   		
   		fondoVisible.drawImage(fondo, 0, 0, this);
    }
   
    public boolean mouseDown(Event evento, int x, int y){
   		Point click; //Un objeto de la clase Point tiene atributos posX y posY y nos dice las coordenadas d�nde se ha hecho click
   		click = new Point(x/Hueco.DIM, y/Hueco.DIM); //Los valores de posX y posY del raton que recibe el evento son en pixels y tenemos que traducirlo a la tabla
   		// Ejemplo: Si clickasemos en el punto (100,100) y si dividimos 100/48 = 2 (nos quedamos con los enteros) y ser�a 2:2 que ser�a fila 2 y columana 2, posici�n 13
   		if(mover(click)){//If siempre recibe un valor booleano con valor cierto. La funci�n mover() da un valor cierto 
   			acierto.play();
   			if(comprobar()){ //if(comprobar()==true)
   				exito.play();
   			}
   			repaint();
   		}else{ //Sino da un valor cierto la funci�n mover() har�..
   			error.play();
   		}
   		
   		return true;
    }
   
   	public boolean mover(Point click){//La funci�n espera recibir sobre "quien" o "que" casilla estamos preguntando si se puede mover
   		Point desplazamiento, hasta;
   		desplazamiento = new Point(delta(click.x, blanco.x), delta(click.y, blanco.y)); //La funci�n delta nos devolver� un entero que indique hacia d�nde se va a realizar el desplazamiento, los valores solo pueden ser: -1, 0 y  1
   		if((desplazamiento.x != 0) && (desplazamiento.y !=0)){ //Porque estamos haciendo click en una casilla que no coincida ni en filas ni en columnas con el espacio en blanco
   			return false;
   		}
   		if((desplazamiento.x == 0) && (desplazamiento.y == 0)){//Porque ser�a click en el espacio en blanco
   			return false;
   		}
   		
   		hasta = new Point((click.x + desplazamiento.x), (click.y + desplazamiento.y)); // Hasta es igual a click + desplazamiento
   		if(!((hasta.x == blanco.x)&& (hasta.y == blanco.y))){ //Si las coordenadas de "hasta" no coinciden a las coordenadas del hueco "blanco" 
   			mover(hasta); // hasta es el valor que se le pasa a mover(Point click) y por tanto click adquiere su valor. Y esto sucede hasta que hasta toma el valor del hueco en blanco que entonces se sale del bucle 
   						  // y ese valor de hasta no se pasa a click, es decir, click obtiene la posici�n de la casilla anterior al hueco en blanco que ahora coincide con hasta.
   		}
   		huecos[blanco.x][blanco.y].setImage(huecos[click.x][click.y].getImage()); //Hay que cambiarle la imagen a blanco (se sustituye por la imagen de click) al salir del bucle cuando hasta coincide con blanco
   		huecos[blanco.x][blanco.y].valor = huecos[click.x][click.y].valor;
   		huecos[click.x][click.y].setImage(null);
   		huecos[click.x][click.y].valor=25;
   		blanco = click;
   		   		
   		return true;
    }
    
    public int delta(int a, int b){ //La funci�n espera recibir dos enteros
    	if(a == b){
    		return 0;
    	}else{
    		return ((b-a)/Math.abs(b-a)); //abs(valor absoluto) es una funci�n est�tica de la clase Math
    		/* Ejemplo: b = 3 ; a = 5
    		 * b - a = 3 - 5 = -2
    		 * valor absoluto de (b-a) = 3- 5 = 2
    		 * -2 / 2 = -1
    		 *  (b-a)/Math.abs(b-a), nos dar� 1 o -1, que nos permite conocer si se ha movido y hacia que direcci�n
    		 *
    		 * Ejemplo2: Si hago click en la pos 2:2
    		 * Para ejeX: delta(2 , 1) = -1
    		 * Para ejeY: delta(2, 2) = 0
    		 * Resultado (-1:0)
    		 * 
    		 *
    		 */
    	}
    }
    
    public boolean action(Event evento, Object obj){
    	if(evento.target instanceof Button){
			if("Empezar".equals(evento.arg)){ 
    			for(int i = 0; i < 200; i++){
    				mover(new Point((int)(Math.random()*5),((int)(Math.random()*5))));
    				repaint();
    			}
    			return true;	
    		}
		}
		
		return false;
	}
	
	public boolean comprobar(){ //No hace falta que reciba nada porque puede acceder al atributo de la clase de manera autom�tica por lo que puede hacer la comprobaci�n sin necesidad de otro parametro
		for(int i = 0; i < huecos.length; i++){ //Para recorrer el array bidimensional usamos un bucle anidado
			for(int j = 0; j < huecos[i].length; j++){//Vector dentro del bucle
				if(((i * SIZE)+j +1) != huecos[i][j].valor){//Si el valor no es igual al que deber�a tener la funci�n se corta
					return false;
				}
			}
		}
		return true; //Si la funci�n no se corta, el valor es cierto
	}
   
    
}
//Crear una funci�n que nos indique si se puede mover la casilla o no. Si es cierto o no que se pueda mover la casilla en la que se ha hecho click
//Blanco ser� un objeto de la clase poi{nt que nos indique el hueco en blanco