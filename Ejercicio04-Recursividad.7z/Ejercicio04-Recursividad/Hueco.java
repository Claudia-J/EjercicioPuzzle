import java.awt.*;
import java.util.*;
import java.applet.*;

public class Hueco {
	public static final int DIM = 48;
	private Image imagen;
	int valor;
	
    public Hueco(Image img, int v) {
    	imagen = img;
    	valor = v;
    }
    
    public void dibujar(Graphics papel, Applet miApplet, int x, int y){
    	if(imagen != null){
    		papel.drawImage(imagen, x*DIM, y* DIM, miApplet); //Pasamos x e  y, que ser�an las posiciones dentro de la tabla en el eje de las X y de las Y
    	}
    }
    
    public void setImage(Image img){
    	imagen = img;
    }
    
    public Image getImage(){
    	
    	return imagen;
    }
    
    
}